<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProspectParent;
use App\Models\InvitonalCode;
use App\Models\Payment_Sps;
use App\Models\Messages;
use App\Models\Student;
use App\Models\Course;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\PaymentSpController;
use App\Http\Controllers\MessageController;
use App\Http\Controllers\WhatsAppController;
use App\Http\Controllers\inviteController;

class paymentSubController extends Controller {}
